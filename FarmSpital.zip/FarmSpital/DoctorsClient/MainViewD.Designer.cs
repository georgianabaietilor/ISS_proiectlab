﻿
namespace DoctorsClient {
    partial class MainViewD {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLoggedUser = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridViewPrescriptions = new System.Windows.Forms.DataGridView();
            this.DateAndTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Patient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewPrescriptionItems = new System.Windows.Forms.DataGridView();
            this.DrugName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrescribedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dosage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxDetails = new System.Windows.Forms.TextBox();
            this.btnDeletePrescription = new System.Windows.Forms.Button();
            this.btnDeliverPrescription = new System.Windows.Forms.Button();
            this.btnUpdatePrescription = new System.Windows.Forms.Button();
            this.btnAddPrescription = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptionItems)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLoggedUser
            // 
            this.lblLoggedUser.AutoSize = true;
            this.lblLoggedUser.Location = new System.Drawing.Point(-4, 9);
            this.lblLoggedUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLoggedUser.Name = "lblLoggedUser";
            this.lblLoggedUser.Size = new System.Drawing.Size(186, 25);
            this.lblLoggedUser.TabIndex = 0;
            this.lblLoggedUser.Text = "Currently logged in: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-4, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prescriptions";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(588, 178);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Prescribed Drugs";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(588, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Prescription Details";
            // 
            // dataGridViewPrescriptions
            // 
            this.dataGridViewPrescriptions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPrescriptions.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridViewPrescriptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrescriptions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DateAndTime,
            this.Patient,
            this.Status});
            this.dataGridViewPrescriptions.Location = new System.Drawing.Point(1, 117);
            this.dataGridViewPrescriptions.MultiSelect = false;
            this.dataGridViewPrescriptions.Name = "dataGridViewPrescriptions";
            this.dataGridViewPrescriptions.ReadOnly = true;
            this.dataGridViewPrescriptions.RowHeadersVisible = false;
            this.dataGridViewPrescriptions.RowHeadersWidth = 51;
            this.dataGridViewPrescriptions.RowTemplate.Height = 24;
            this.dataGridViewPrescriptions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPrescriptions.Size = new System.Drawing.Size(586, 423);
            this.dataGridViewPrescriptions.TabIndex = 4;
            this.dataGridViewPrescriptions.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPrescriptions_CellClick);
            this.dataGridViewPrescriptions.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dataGridViewPrescriptions_CellFormatting);
            // 
            // DateAndTime
            // 
            this.DateAndTime.DataPropertyName = "DateAndTime";
            this.DateAndTime.HeaderText = "Prescribed On";
            this.DateAndTime.MinimumWidth = 6;
            this.DateAndTime.Name = "DateAndTime";
            this.DateAndTime.ReadOnly = true;
            // 
            // Patient
            // 
            this.Patient.DataPropertyName = "Patient";
            this.Patient.HeaderText = "Patient";
            this.Patient.MinimumWidth = 6;
            this.Patient.Name = "Patient";
            this.Patient.ReadOnly = true;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // dataGridViewPrescriptionItems
            // 
            this.dataGridViewPrescriptionItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPrescriptionItems.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridViewPrescriptionItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrescriptionItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DrugName,
            this.PrescribedQuantity,
            this.Dosage});
            this.dataGridViewPrescriptionItems.Location = new System.Drawing.Point(593, 206);
            this.dataGridViewPrescriptionItems.MultiSelect = false;
            this.dataGridViewPrescriptionItems.Name = "dataGridViewPrescriptionItems";
            this.dataGridViewPrescriptionItems.ReadOnly = true;
            this.dataGridViewPrescriptionItems.RowHeadersVisible = false;
            this.dataGridViewPrescriptionItems.RowHeadersWidth = 51;
            this.dataGridViewPrescriptionItems.RowTemplate.Height = 24;
            this.dataGridViewPrescriptionItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPrescriptionItems.Size = new System.Drawing.Size(468, 395);
            this.dataGridViewPrescriptionItems.TabIndex = 5;
            // 
            // DrugName
            // 
            this.DrugName.DataPropertyName = "Drug";
            this.DrugName.HeaderText = "Drug Name";
            this.DrugName.MinimumWidth = 6;
            this.DrugName.Name = "DrugName";
            this.DrugName.ReadOnly = true;
            // 
            // PrescribedQuantity
            // 
            this.PrescribedQuantity.DataPropertyName = "PrescribedQuantity";
            this.PrescribedQuantity.HeaderText = "Quantity";
            this.PrescribedQuantity.MinimumWidth = 6;
            this.PrescribedQuantity.Name = "PrescribedQuantity";
            this.PrescribedQuantity.ReadOnly = true;
            // 
            // Dosage
            // 
            this.Dosage.DataPropertyName = "Dosage";
            this.Dosage.HeaderText = "Dosage";
            this.Dosage.MinimumWidth = 6;
            this.Dosage.Name = "Dosage";
            this.Dosage.ReadOnly = true;
            // 
            // textBoxDetails
            // 
            this.textBoxDetails.Location = new System.Drawing.Point(593, 37);
            this.textBoxDetails.Multiline = true;
            this.textBoxDetails.Name = "textBoxDetails";
            this.textBoxDetails.ReadOnly = true;
            this.textBoxDetails.Size = new System.Drawing.Size(468, 138);
            this.textBoxDetails.TabIndex = 6;
            // 
            // btnDeletePrescription
            // 
            this.btnDeletePrescription.BackColor = System.Drawing.Color.Red;
            this.btnDeletePrescription.Location = new System.Drawing.Point(1, 548);
            this.btnDeletePrescription.Name = "btnDeletePrescription";
            this.btnDeletePrescription.Size = new System.Drawing.Size(184, 60);
            this.btnDeletePrescription.TabIndex = 7;
            this.btnDeletePrescription.Text = "Delete Prescription";
            this.btnDeletePrescription.UseVisualStyleBackColor = false;
            this.btnDeletePrescription.Click += new System.EventHandler(this.btnDeletePrescription_Click);
            // 
            // btnDeliverPrescription
            // 
            this.btnDeliverPrescription.BackColor = System.Drawing.Color.YellowGreen;
            this.btnDeliverPrescription.Location = new System.Drawing.Point(399, 548);
            this.btnDeliverPrescription.Name = "btnDeliverPrescription";
            this.btnDeliverPrescription.Size = new System.Drawing.Size(188, 60);
            this.btnDeliverPrescription.TabIndex = 8;
            this.btnDeliverPrescription.Text = "Deliver Prescription";
            this.btnDeliverPrescription.UseVisualStyleBackColor = false;
            this.btnDeliverPrescription.Click += new System.EventHandler(this.btnDeliverPrescription_Click);
            // 
            // btnUpdatePrescription
            // 
            this.btnUpdatePrescription.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnUpdatePrescription.Location = new System.Drawing.Point(191, 548);
            this.btnUpdatePrescription.Name = "btnUpdatePrescription";
            this.btnUpdatePrescription.Size = new System.Drawing.Size(202, 60);
            this.btnUpdatePrescription.TabIndex = 9;
            this.btnUpdatePrescription.Text = "Update Prescription";
            this.btnUpdatePrescription.UseVisualStyleBackColor = false;
            this.btnUpdatePrescription.Click += new System.EventHandler(this.btnUpdatePrescription_Click);
            // 
            // btnAddPrescription
            // 
            this.btnAddPrescription.BackColor = System.Drawing.Color.LimeGreen;
            this.btnAddPrescription.Location = new System.Drawing.Point(1, 37);
            this.btnAddPrescription.Name = "btnAddPrescription";
            this.btnAddPrescription.Size = new System.Drawing.Size(586, 49);
            this.btnAddPrescription.TabIndex = 10;
            this.btnAddPrescription.Text = "Add New Prescription";
            this.btnAddPrescription.UseVisualStyleBackColor = false;
            this.btnAddPrescription.Click += new System.EventHandler(this.btnAddPrescription_Click);
            // 
            // MainViewD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1073, 613);
            this.Controls.Add(this.btnAddPrescription);
            this.Controls.Add(this.btnUpdatePrescription);
            this.Controls.Add(this.btnDeliverPrescription);
            this.Controls.Add(this.btnDeletePrescription);
            this.Controls.Add(this.textBoxDetails);
            this.Controls.Add(this.dataGridViewPrescriptionItems);
            this.Controls.Add(this.dataGridViewPrescriptions);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblLoggedUser);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainViewD";
            this.Text = "View Prescriptions Doctors";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainViewD_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptionItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLoggedUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridViewPrescriptions;
        private System.Windows.Forms.DataGridView dataGridViewPrescriptionItems;
        private System.Windows.Forms.TextBox textBoxDetails;
        private System.Windows.Forms.Button btnDeletePrescription;
        private System.Windows.Forms.Button btnDeliverPrescription;
        private System.Windows.Forms.Button btnUpdatePrescription;
        private System.Windows.Forms.Button btnAddPrescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateAndTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Patient;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn DrugName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrescribedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dosage;
    }
}