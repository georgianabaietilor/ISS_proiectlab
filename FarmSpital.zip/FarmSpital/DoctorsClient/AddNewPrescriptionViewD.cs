﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Common.Entities;

namespace DoctorsClient {
    public partial class AddNewPrescriptionViewD : Form {
        private readonly ControllerD _controller;
        private Prescription _currentPrescription;
        private Drug _selectedDrug;
        private PrescriptionItem _selectedItem;

        private List<Drug> _drugsModel;
        private List<Patient> _patientsModel;
        private List<PrescriptionItem> _itemsModel;
        public AddNewPrescriptionViewD(ControllerD controller, Prescription prescriptionToBeUpdated = null)
        {
            InitializeComponent();
            _controller = controller;
            _drugsModel = _controller.FilterDrugsByName("").ToList();
            dataGridViewDrugs.DataSource = _drugsModel;
            HideUnwantedDrugColumns();
            _patientsModel = _controller.FindAllPatients().ToList();
            comboBoxPatients.DataSource = _patientsModel;
            _currentPrescription = prescriptionToBeUpdated;
            comboBoxPatients.SelectedItem = null;

            if (_currentPrescription == null)
                _itemsModel = new List<PrescriptionItem>();
            else {
                _itemsModel = _currentPrescription.PrescriptionItems.ToList();
                textBoxPrescriptionDetails.Text = _currentPrescription.Details;
                comboBoxPatients.SelectedItem = _patientsModel.FirstOrDefault(p => p.Id==_currentPrescription.PatientId);
                comboBoxPatients.Enabled = false;
                UpdateItems();
            }
        }
        private void HideUnwantedDrugColumns()
        {
            dataGridViewDrugs.Columns["Id"].Visible = false;
            dataGridViewDrugs.Columns["PrescriptionItems"].Visible = false;
        }
        private void HideUnwantedItemColumns()
        {
            dataGridViewPrescribedItems.Columns["Id"].Visible = false;
            dataGridViewPrescribedItems.Columns["PrescriptionId"].Visible = false;
            dataGridViewPrescribedItems.Columns["Prescription"].Visible = false;
            dataGridViewPrescribedItems.Columns["DrugId"].Visible = false;
        }
        private void UpdateItems()
        {
            dataGridViewPrescribedItems.DataSource = null;
            dataGridViewPrescribedItems.DataSource = _itemsModel;
            HideUnwantedItemColumns();
        }
        private void UpdateDrugs()
        {
            dataGridViewDrugs.DataSource = null;
            dataGridViewDrugs.DataSource = _drugsModel;
            HideUnwantedDrugColumns();
        }
        private void ClearDrugDetailFields()
        {
            textBoxQuantity.Text = "";
            textBoxDosage.Text = "";
        }
        private void textBoxSearchDrug_TextChanged(object sender, EventArgs e)
        {
            _drugsModel = _controller.FilterDrugsByName(textBoxSearchDrug.Text.Trim()).ToList();
            UpdateDrugs();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            if (_selectedItem == null) {
                MessageBox.Show("Select the item you want to remove");
                return;
            }
            _itemsModel.RemoveAll(it => it.DrugId == _selectedItem.DrugId);
            _selectedItem = null;
            lblCurrentlyPrescribing.Text = "Curently prescribing ...";
            UpdateItems();
        }

        private void btnUpdateItem_Click(object sender, EventArgs e)
        {
            if (_selectedItem == null) {
                MessageBox.Show("Select the item you want to update and update quantity and dosage first");
                return;
            }
            var quantityStr = textBoxQuantity.Text.Trim();
            var dosage = textBoxDosage.Text.Trim();
            if (string.IsNullOrWhiteSpace(quantityStr) || string.IsNullOrWhiteSpace(dosage)) {
                MessageBox.Show("Please insert quantity and dosage.");
                return;
            }
            if (!int.TryParse(quantityStr, out int quantity) || quantity <= 0) {
                MessageBox.Show("Quantity should be a number greater than 0.");
                return;
            }
            if (quantity + _selectedItem.Drug.ReservedQuantity > _selectedItem.Drug.AvailableQuantity) {
                MessageBox.Show("The requested quantity is not available.");
                return;
            }
            _selectedItem.PrescribedQuantity = quantity;
            _selectedItem.Dosage = dosage;
            UpdateItems();
        }

        private void btnSendPrescription_Click(object sender, EventArgs e)
        {
            var details = textBoxPrescriptionDetails.Text.Trim();
            var patient = comboBoxPatients.SelectedItem as Patient;

            if ( !_itemsModel.Any()) {
                MessageBox.Show("Prescription should contain at least one drug.");
                return;
            }
            if (patient == null) {
                MessageBox.Show("Select patient first.");
                return;
            }

            if (_currentPrescription == null) {
                var newPrescription = new Prescription() 
                {
                    DateAndTime = DateTime.Now,
                    Status = PrescriptionStatus.Sent,
                    Details = details,
                    DoctorId = _controller.LoggedDoctor.Id,
                    PharmacistId=1,
                    PatientId = patient.Id,
                    PrescriptionItems = _itemsModel
                };
                if (_controller.AddNewPrescription(newPrescription))
                    Close();
                else
                    MessageBox.Show("An error occured. Prescription was not sent.");
            }
            else {
                UpdatePrescription(details);
                Close();
            }
        }
        private void UpdatePrescription(string details)
        {
            var newAddedItems = _itemsModel.Where(ip => ip.Prescription == null).ToList();
            var deletedItemsIds = _currentPrescription.PrescriptionItems.Select(pi => pi.Id)
                .Except(_itemsModel.Select(i => i.Id)).ToList();
            var updatedItems = _itemsModel.Where(ip => ip.Prescription != null && ! deletedItemsIds.Contains(ip.Id)).ToList();
            _currentPrescription.Details = details;
            _currentPrescription.Status = PrescriptionStatus.Sent;
            _controller.UpdatePrescription(_currentPrescription, newAddedItems, deletedItemsIds, updatedItems);
        }
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (_selectedDrug == null) {
                MessageBox.Show("Please select a drug and add quantity and dosage first.");
                return;
            }
            var quantityStr = textBoxQuantity.Text.Trim();
            var dosage = textBoxDosage.Text.Trim();
            if (string.IsNullOrWhiteSpace(quantityStr) || string.IsNullOrWhiteSpace(dosage)) {
                MessageBox.Show("Please insert quantity and dosage.");
                return;
            }
            if (! int.TryParse(quantityStr,out int quantity) || quantity <= 0) {
                MessageBox.Show("Quantity should be a number greater than 0.");
                return;
            }
            if ( quantity + _selectedDrug.ReservedQuantity > _selectedDrug.AvailableQuantity) {
                MessageBox.Show("The requested quantity is not available.");
                return;
            }
            var existingItem = _itemsModel.FirstOrDefault(it => it.DrugId == _selectedDrug.Id);
            if (existingItem == null) {
                _itemsModel.Add(new PrescriptionItem() {
                    PrescribedQuantity = quantity,
                    Dosage = dosage,
                    DrugId = _selectedDrug.Id,
                    Drug = _selectedDrug
                });
                ClearDrugDetailFields();
            }
            else {
                MessageBox.Show("Drug already added. Press 'Update Prescribed Drug' if you want to update it.");
                return;
            }
            UpdateItems();
        }

        private void dataGridViewDrugs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _selectedDrug = dataGridViewDrugs.SelectedRows?[0].DataBoundItem as Drug;
            if (_selectedDrug != null) {
                lblCurrentlyPrescribing.Text = $"Currently prescribing {_selectedDrug.Name}";
                _selectedItem = null;
            }
        }

        private void dataGridViewPrescribedItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _selectedItem = dataGridViewPrescribedItems.SelectedRows?[0].DataBoundItem as PrescriptionItem;
            if (_selectedItem != null) {
                lblCurrentlyPrescribing.Text = $"Currently prescribing {_selectedItem.Drug.Name}";
                textBoxQuantity.Text = $"{_selectedItem.PrescribedQuantity}";
                textBoxDosage.Text = _selectedItem.Dosage;
                _selectedDrug = null;
            }
        }
    }
}
