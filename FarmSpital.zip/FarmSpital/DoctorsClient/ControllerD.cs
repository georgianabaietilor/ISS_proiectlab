﻿using System;
using System.Collections.Generic;
using Common.Entities;
using Common.Events;
using Common.Interfaces;

namespace DoctorsClient {
    public class ControllerD : MarshalByRefObject, IObserver {
        private readonly IService _service;
        public event EventHandler<AppEventArgs> UpdateEvent;
        public Doctor LoggedDoctor { get; set; }

        public ControllerD(IService service)
        {
            _service = service;
        }

        public void Login(string username, string password)
        {
            var dr = new Doctor() { Username = username, Password = password };
            LoggedDoctor = (Doctor)_service.Login(dr, this);
        }
        public void Logout()
        {
            _service.Logout(LoggedDoctor.Username);
            LoggedDoctor = null;
        }
        public IEnumerable<Prescription> FindAllPrescriptionsByStatusAndDoctor()
        {
            var statuses = new PrescriptionStatus[] 
            { 
                PrescriptionStatus.Honored, 
                PrescriptionStatus.Processing, 
                PrescriptionStatus.Rejected, 
                PrescriptionStatus.Sent 
            };
            return _service.FilterByStatusAndDoctor(statuses, LoggedDoctor.Id);
        }
        public IEnumerable<Patient> FindAllPatients()
        {
            return _service.FindAllPatients();
        }
        public IEnumerable<Drug> FilterDrugsByName(string name)
        {
            return _service.FilterDrugsByName(name);
        }
        public bool AddNewPrescription(Prescription prescription)
        {
            return _service.AddNewPrescription(prescription);
        }

        public void UpdatePrescription(Prescription prescription, List<PrescriptionItem> newAddedItems, List<int> deletedItemsIds, List<PrescriptionItem> updatedItems)
        {
            _service.UpdatePrescription(prescription, newAddedItems, deletedItemsIds, updatedItems);
        }
        protected virtual void OnUserEvents(AppEventArgs ev)
        {
            if (UpdateEvent == null)
                return;
            UpdateEvent(this, ev);
        }
        public void PrescriptionWasAdded(Prescription prescription)
        {
            var eventArgs = new AppEventArgs(AppUserEvent.PrescriptionAdded,prescription);
            OnUserEvents(eventArgs);
        }


        public void PrescriptionWasDeleted(int id)
        {
            var eventArgs = new AppEventArgs(AppUserEvent.PrescriptionDeleted, id);
            OnUserEvents(eventArgs);
        }

        public void PrescriptionWasUpdated(Prescription prescription)
        {
            var eventArgs = new AppEventArgs(AppUserEvent.PrescriptionUpdated, prescription);
            OnUserEvents(eventArgs);
        }

        public void DeletePrescription(int id)
        {
            _service.DeletePrescription(id);
        }

        public void UpdatePrescriptionStatus(Prescription prescription, PrescriptionStatus newStatus)
        {
            _service.UpdatePrescriptionStatus(prescription, newStatus);
        }
        //ca sa mearga .NET remoting
        public override object InitializeLifetimeService()
        {
            return null;
        }
    }
}
