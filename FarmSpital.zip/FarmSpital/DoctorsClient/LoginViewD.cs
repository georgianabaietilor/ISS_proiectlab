﻿using System;
using System.Threading;
using System.Windows.Forms;
using Common.Exceptions;

namespace DoctorsClient {
    public partial class LoginViewD : Form {
        private readonly ControllerD _controller;
        private Thread _thread;
        public LoginViewD(ControllerD controller)
        {
            InitializeComponent();
            _controller = controller;
            lblLoginFail.Text = "";
        }

        private void btnLogin_Click(object sender, System.EventArgs e)
        {
            var username = textBoxUsername.Text.Trim();
            var password = textBoxPassword.Text.Trim();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password)) {
                lblLoginFail.Text = "Please enter credentials";
                return;
            }
            try {
                _controller.Login(username, password);
                ShowMainPage();
            }
            catch (AppException ex) {
                lblLoginFail.Text = ex.Message;
            }
            catch (Exception ex) {
                MessageBox.Show(this, ex.Message, "Login error");
                Console.WriteLine(ex.StackTrace);
            }
        }

        private void ShowMainPage()
        {
            Close();
            _thread = new Thread(OpenMainWindow);
            _thread.SetApartmentState(ApartmentState.STA);
            _thread.Start();
        }

        private void OpenMainWindow()
        {
            Application.Run(new MainViewD(_controller));
        }
    }
}
