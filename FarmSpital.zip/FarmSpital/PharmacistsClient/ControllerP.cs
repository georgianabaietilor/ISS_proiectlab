﻿using System;
using System.Collections.Generic;
using System.Linq;
using Common.Entities;
using Common.Events;
using Common.Interfaces;

namespace PharmacistsClient {
    public class ControllerP : MarshalByRefObject, IObserver {
        private readonly IService _service;
        public event EventHandler<AppEventArgs> UpdateEvent;
        public Pharmacist LoggedPharmacist { get; set; }

        public ControllerP(IService service)
        {
            _service = service;
        }

        public void Login(string username, string password)
        {
            var dr = new Pharmacist() { Username = username, Password = password };
            LoggedPharmacist = (Pharmacist)_service.Login(dr, this);
        }
        public void Logout()
        {
            _service.Logout(LoggedPharmacist.Username);
            LoggedPharmacist = null;
        }
        public void UpdatePrescriptionStatus(Prescription prescription, PrescriptionStatus newStatus)
        {
            _service.UpdatePrescriptionStatus(prescription, newStatus);
        }
        protected virtual void OnUserEvents(AppEventArgs ev)
        {
            if (UpdateEvent == null)
                return;
            UpdateEvent(this, ev);
        }
        public void PrescriptionWasAdded(Prescription prescription)
        {
            var eventArgs = new AppEventArgs(AppUserEvent.PrescriptionAdded, prescription);
            OnUserEvents(eventArgs);
        }
        public void PrescriptionWasDeleted(int id)
        {
            var eventArgs = new AppEventArgs(AppUserEvent.PrescriptionDeleted, id);
            OnUserEvents(eventArgs);
        }

        internal IEnumerable<Prescription> FindAllSentAndProcesssingPrescriptions()
        {
            var statuses = new PrescriptionStatus[]
            {
                PrescriptionStatus.Processing,
                PrescriptionStatus.Sent
            };
            return _service.FilterByStatusAndDoctor(statuses).OrderBy(p => p.DateAndTime);
        }

        public void PrescriptionWasUpdated(Prescription prescription)
        {
            var eventArgs = new AppEventArgs(AppUserEvent.PrescriptionUpdated, prescription);
            OnUserEvents(eventArgs);
        }

        public void RejectPrescription(Prescription prescription, string rejectionMotiv)
        {
            _service.RejectPrescription(prescription, rejectionMotiv);
        }

        public void HonorPrescription(Prescription prescription)
        {
            _service.HonorPrescription(prescription);
        }
        //ca sa mearga .NET remoting
        public override object InitializeLifetimeService()
        {
            return null;
        }
    }
}
