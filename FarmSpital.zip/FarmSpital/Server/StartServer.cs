﻿using System;
using System.Collections;
using System.Configuration;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;
using Server.Repository;
using Server.Service;

namespace Server {
    class StartServer {
        static void Main(string[] args)
        {
            BinaryServerFormatterSinkProvider serverProv = new BinaryServerFormatterSinkProvider();
            serverProv.TypeFilterLevel = System.Runtime.Serialization.Formatters.TypeFilterLevel.Full;
            BinaryClientFormatterSinkProvider clientProv = new BinaryClientFormatterSinkProvider();
            IDictionary props = new Hashtable();

            props["port"] = 65000;
            TcpChannel channel = new TcpChannel(props, clientProv, serverProv);
            ChannelServices.RegisterChannel(channel, false);

            using (var context = new AppDbContext(ConfigurationManager.ConnectionStrings["FarmSpital"].ConnectionString)) {
                var doctorRepository = new DbDoctorRepository(context);
                var pharmacistRepository = new DbPharmacistRepository(context);
                var drugRepository = new DbDrugRepository(context);
                var patientRepository = new DbPatientRepository(context);
                var prescriptionRepository = new DbPrescriptionRepository(context);
                var prescriptionItemRepository = new DbPrescriptionItemRepository(context);

                var service = new HospitalPharmacyService(doctorRepository, 
                    pharmacistRepository, 
                    drugRepository, 
                    patientRepository, 
                    prescriptionRepository,
                    prescriptionItemRepository);

                RemotingServices.Marshal(service, "HospitalPharmacyService");

                Console.WriteLine("Server started...waiting for clients");
                Console.WriteLine("Press any key to stop server");
                Console.ReadKey();
            }
        }
    }
}
