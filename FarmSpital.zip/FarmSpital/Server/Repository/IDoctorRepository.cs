﻿using System.Collections.Generic;
using System.Linq;
using Common.Entities;

namespace Server.Repository {
    public interface IDoctorRepository : IRepository<Doctor, int> {
        Doctor FindOne(string username);
    }

    public class DbDoctorRepository : IDoctorRepository {
        private readonly AppDbContext _context;
        public DbDoctorRepository(AppDbContext context)
        {
            _context = context;
        }
        public Doctor FindOne(string username)
        {
            return _context.Doctors.FirstOrDefault(d => d.Username.Equals(username));
        }

        #region not implemented
        public bool Delete(int id)
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Doctor> FindAll()
        {
            throw new System.NotImplementedException();
        }

        public Doctor FindOne(int id)
        {
            throw new System.NotImplementedException();
        }

        public Doctor Save(Doctor entity)
        {
            throw new System.NotImplementedException();
        }

        public bool Update(Doctor entity)
        {
            throw new System.NotImplementedException();
        }
        #endregion
    }
}
