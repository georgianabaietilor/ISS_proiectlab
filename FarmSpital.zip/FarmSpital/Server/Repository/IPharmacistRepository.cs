﻿using System.Collections.Generic;
using System.Linq;
using Common.Entities;

namespace Server.Repository {
    public interface IPharmacistRepository : IRepository<Pharmacist,int>{
        Pharmacist FindOne(string username);
    }

    public class DbPharmacistRepository : IPharmacistRepository {
        private readonly AppDbContext _context;

        public DbPharmacistRepository(AppDbContext context)
        {
            _context = context;
        }
        public Pharmacist FindOne(string username)
        {
            return _context.Pharmacists.FirstOrDefault(p => p.Username.Equals(username));
        }

        #region not implemented

        public bool Delete(int id)
        {
            throw new System.NotImplementedException();
        }

        public IEnumerable<Pharmacist> FindAll()
        {
            throw new System.NotImplementedException();
        }


        public Pharmacist FindOne(int id)
        {
            throw new System.NotImplementedException();
        }

        public Pharmacist Save(Pharmacist entity)
        {
            throw new System.NotImplementedException();
        }

        public bool Update(Pharmacist entity)
        {
            throw new System.NotImplementedException();
        }
        #endregion
    }
}
