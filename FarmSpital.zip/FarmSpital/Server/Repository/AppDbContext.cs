﻿using System.Data.Entity;
using Common.Entities;

namespace Server.Repository {
    public class AppDbContext : DbContext{
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Pharmacist> Pharmacists { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Drug> Drugs { get; set; }
        public DbSet<Prescription> Prescriptions { get; set; }
        public DbSet<PrescriptionItem> PrescriptionItems { get; set; }


        public AppDbContext()
        {

        }

        public AppDbContext(string dbName) : base(dbName)
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            this.Configuration.ProxyCreationEnabled = false;
        }
    }
}
