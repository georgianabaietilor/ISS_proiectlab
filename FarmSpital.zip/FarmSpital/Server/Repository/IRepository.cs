﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Server.Repository {
    public interface IRepository<Entity, Id> {
        Entity FindOne(Id id);
        IEnumerable<Entity> FindAll();
        Entity Save(Entity entity);
        bool Update(Entity entity);
        bool Delete(Id id);
    }
}
