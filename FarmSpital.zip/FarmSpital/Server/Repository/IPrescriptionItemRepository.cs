﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.Entities;

namespace Server.Repository {
    public interface IPrescriptionItemRepository : IRepository<PrescriptionItem, int>{
    }

    public class DbPrescriptionItemRepository : IPrescriptionItemRepository {
        private readonly AppDbContext _context;

        public DbPrescriptionItemRepository(AppDbContext context)
        {
            _context = context;
        }

        public bool Delete(int id)
        {
            var itemToBeDeleted = _context.PrescriptionItems.FirstOrDefault(pi => pi.Id == id);
            if (itemToBeDeleted == null)
                return false;
            var drugId = itemToBeDeleted.DrugId;
            var prescribedQuantity = itemToBeDeleted.PrescribedQuantity;
            var drugToBeUpdated = _context.Drugs.FirstOrDefault(d => d.Id == drugId);
            if (drugToBeUpdated != null) {
                drugToBeUpdated.ReservedQuantity -= prescribedQuantity;
                _context.PrescriptionItems.Remove(itemToBeDeleted);
                _context.SaveChanges();
                return true;
            }
            return false;
        }

        public PrescriptionItem Save(PrescriptionItem entity)
        {
            var drugId = entity.DrugId;
            var drugToBeUpdated = _context.Drugs.FirstOrDefault(d => d.Id == drugId);
            if (drugToBeUpdated != null) {
                drugToBeUpdated.ReservedQuantity += entity.PrescribedQuantity;
                _context.PrescriptionItems.Add(entity);
                _context.SaveChanges();
                return null;
            }
            return entity;
        }

        public bool Update(PrescriptionItem entity)
        {
            var itemToBeUpdated = _context.PrescriptionItems.FirstOrDefault(pi => pi.Id == entity.Id);
            if (itemToBeUpdated == null)
                return false;
            var drugId = itemToBeUpdated.DrugId;
            var prescribedQuantity = itemToBeUpdated.PrescribedQuantity;
            var drugToBeUpdated = _context.Drugs.FirstOrDefault(d => d.Id == drugId);
            if (drugToBeUpdated != null) {
                drugToBeUpdated.ReservedQuantity += (-prescribedQuantity + entity.PrescribedQuantity);
                itemToBeUpdated.PrescribedQuantity = entity.PrescribedQuantity;
                itemToBeUpdated.Dosage = entity.Dosage;
                var changes = _context.SaveChanges();
                return true;
            }
            return false;
        }

        #region not implemented
        public IEnumerable<PrescriptionItem> FindAll()
        {
            throw new NotImplementedException();
        }

        public PrescriptionItem FindOne(int id)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}
