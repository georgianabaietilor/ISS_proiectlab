﻿using System;

namespace Common.Entities {
    [Serializable]
    public class Pharmacist : MedicalStaff {
    }
}
