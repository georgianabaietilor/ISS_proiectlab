﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Common.Entities {
    [Serializable]
    public class Patient {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(13)]
        public string CNP { get; set; }
        public override string ToString()
        {
            return $"{Name} - {CNP}";
        }
    }
}
