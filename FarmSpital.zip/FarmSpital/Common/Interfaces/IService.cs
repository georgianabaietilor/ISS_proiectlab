﻿using System.Collections.Generic;
using Common.Entities;

namespace Common.Interfaces {
    public interface IService {
        MedicalStaff Login(MedicalStaff staff, IObserver client);
        void Logout(string username);
        IEnumerable<Drug> FilterDrugsByName(string name);
        bool AddNewPrescription(Prescription prescription);
        bool DeletePrescription(int id);
        bool UpdatePrescription(Prescription prescription, List<PrescriptionItem> newAddedItems, List<int> deletedItemsIds, List<PrescriptionItem> updatedItems);
        bool UpdatePrescriptionStatus(Prescription prescription, PrescriptionStatus newStatus);
        bool RejectPrescription(Prescription prescription, string rejectionMotiv);
        void HonorPrescription(Prescription prescription);
        IEnumerable<Patient> FindAllPatients();
        IEnumerable<Prescription> FilterByStatusAndDoctor(IEnumerable<PrescriptionStatus> statuses, int? doctorId = null);
    }
}
