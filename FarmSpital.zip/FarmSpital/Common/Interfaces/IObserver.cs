﻿using Common.Entities;

namespace Common.Interfaces {
    public interface IObserver {
        void PrescriptionWasAdded(Prescription prescription);
        void PrescriptionWasUpdated(Prescription prescription);
        void PrescriptionWasDeleted(int id);
    }
}
