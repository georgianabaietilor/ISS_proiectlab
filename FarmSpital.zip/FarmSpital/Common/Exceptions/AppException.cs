﻿using System;

namespace Common.Exceptions {
    [Serializable]
    public class AppException : Exception {
        public AppException()
        {

        }
        public AppException(string message) : base(message)
        {

        }
        //public AppException(SerializationInfo info, StreamingContext context) : base(info, context)
        //{
        //}
    }
}
