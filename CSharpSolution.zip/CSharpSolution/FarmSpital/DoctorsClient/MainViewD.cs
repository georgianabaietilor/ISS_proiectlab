﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using Common.Entities;
using Common.Events;

namespace DoctorsClient {
    public partial class MainViewD : Form {
        private readonly ControllerD _controller;
        private Prescription _selectedPrescription;

        private List<Prescription> _prescriptionsModel;
        private List<PrescriptionItem> _itemsModel;
        public MainViewD(ControllerD controller)
        {
            InitializeComponent();
            _controller = controller;
            lblLoggedUser.Text = $"Doctor logged in: {_controller.LoggedDoctor.Name} {_controller.LoggedDoctor.Department}";
            _prescriptionsModel = _controller.FindAllPrescriptionsByStatusAndDoctor().ToList();
            dataGridViewPrescriptions.DataSource = _prescriptionsModel;
            HideUnwantedPrescriptionsColumns();
            ShowPrescriptionActionButtons();

            _controller.UpdateEvent += UserUpdate;
        }
        public delegate void UpdateDataGridViewCallBack(DataGridView dataGridView, IList<Prescription> prescriptions);
        private void UserUpdate(object sender, AppEventArgs e)
        {
            switch (e.Type) {
                case AppUserEvent.PrescriptionAdded:
                    var addedPrescription = e.Data as Prescription;
                    if (addedPrescription.Status.Equals(PrescriptionStatus.Honored)
                        || addedPrescription.Status.Equals(PrescriptionStatus.Processing)
                        || addedPrescription.Status.Equals(PrescriptionStatus.Rejected)
                        || addedPrescription.Status.Equals(PrescriptionStatus.Sent))
                        _prescriptionsModel.Add(addedPrescription);
                    dataGridViewPrescriptions.Invoke(new UpdateDataGridViewCallBack(this.UpdateDataGridView), new Object[] { dataGridViewPrescriptions, _prescriptionsModel});
                    break;
                case AppUserEvent.PrescriptionUpdated:
                    var updatedPrescription = e.Data as Prescription;
                    var inModelPrescription = _prescriptionsModel.FirstOrDefault(p => p.Id == updatedPrescription.Id);
                    if (inModelPrescription!= null)
                        _prescriptionsModel.Remove(inModelPrescription);
                    if (updatedPrescription.Status.Equals(PrescriptionStatus.Honored) 
                        || updatedPrescription.Status.Equals(PrescriptionStatus.Processing)
                        || updatedPrescription.Status.Equals(PrescriptionStatus.Rejected)
                        || updatedPrescription.Status.Equals(PrescriptionStatus.Sent))
                        _prescriptionsModel.Add(updatedPrescription);
                    
                    dataGridViewPrescriptions.Invoke(new UpdateDataGridViewCallBack(this.UpdateDataGridView), new Object[] { dataGridViewPrescriptions, _prescriptionsModel });
                    break;
                case AppUserEvent.PrescriptionDeleted:
                    var id = (int)e.Data;
                    var pr = _prescriptionsModel.FirstOrDefault(p => p.Id == id);
                    if (pr != null) {
                        _prescriptionsModel.Remove(pr);
                    }
                    dataGridViewPrescriptions.Invoke(new UpdateDataGridViewCallBack(this.UpdateDataGridView), new Object[] { dataGridViewPrescriptions, _prescriptionsModel });
                    break;
            }
        }
        private void UpdateDataGridView(DataGridView dataGridView, IList<Prescription> prescriptions)
        {
            dataGridView.DataSource = null;
            dataGridView.DataSource = prescriptions;
            HideUnwantedPrescriptionsColumns();
        }
        private void HideUnwantedPrescriptionsColumns()
        {
            dataGridViewPrescriptions.Columns["Id"].Visible = false;
            dataGridViewPrescriptions.Columns["Details"].Visible = false;
            dataGridViewPrescriptions.Columns["DoctorId"].Visible = false;
            dataGridViewPrescriptions.Columns["Doctor"].Visible = false;
            dataGridViewPrescriptions.Columns["PatientId"].Visible = false;
            dataGridViewPrescriptions.Columns["PharmacistId"].Visible = false;
            dataGridViewPrescriptions.Columns["Pharmacist"].Visible = false;
            dataGridViewPrescriptions.Columns["PrescriptionItems"].Visible = false;

        }
        private void HideUnwantedItemColumns()
        {
            dataGridViewPrescriptionItems.Columns["Id"].Visible = false;
            dataGridViewPrescriptionItems.Columns["PrescriptionId"].Visible = false;
            dataGridViewPrescriptionItems.Columns["Prescription"].Visible = false;
            dataGridViewPrescriptionItems.Columns["DrugId"].Visible = false;
        }
        private void UpdateItems()
        {
            dataGridViewPrescriptionItems.DataSource = null;
            dataGridViewPrescriptionItems.DataSource = _itemsModel;
            HideUnwantedItemColumns();
        }
        private void btnAddPrescription_Click(object sender, EventArgs e)
        {
            var addNewPrescriptionWindow = new AddNewPrescriptionViewD(_controller);
            addNewPrescriptionWindow.ShowDialog();
        }

        private void btnDeletePrescription_Click(object sender, EventArgs e)
        {
            if (_selectedPrescription == null) {
                MessageBox.Show("Please select the prescription you want to delete.");
                return;
            }
            if (!_selectedPrescription.Status.Equals(PrescriptionStatus.Sent)) {
                MessageBox.Show("Cannot delete a prescription with status different than Sent.");
                return;
            }
            _controller.DeletePrescription(_selectedPrescription.Id);
        }

        private void btnUpdatePrescription_Click(object sender, EventArgs e)
        {
            if (_selectedPrescription == null) {
                MessageBox.Show("Please select the prescription you want to update.");
                return;
            }
            if (!_selectedPrescription.Status.Equals(PrescriptionStatus.Sent)
                && !_selectedPrescription.Status.Equals(PrescriptionStatus.Rejected)) {
                MessageBox.Show("Cannot update a prescription with status different than Sent/Rejected.");
                return;
            }
            var addNewPrescriptionWindow = new AddNewPrescriptionViewD(_controller, _selectedPrescription);
            addNewPrescriptionWindow.ShowDialog();
        }

        private void btnDeliverPrescription_Click(object sender, EventArgs e)
        {
            if (_selectedPrescription == null) {
                MessageBox.Show("Please select the prescription you want to deliver.");
                return;
            }
            if (!_selectedPrescription.Status.Equals(PrescriptionStatus.Honored)) {
                MessageBox.Show("Cannot deliver a prescription with status different than Honored.");
                return;
            }
            _controller.UpdatePrescriptionStatus(_selectedPrescription, PrescriptionStatus.Delivered);
        }

        private void MainViewD_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) {
                _controller.Logout();
                _controller.UpdateEvent -= UserUpdate;
                Application.Exit();
            }
        }
        private void dataGridViewPrescriptions_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _selectedPrescription = dataGridViewPrescriptions.SelectedRows?[0].DataBoundItem as Prescription;
            if (_selectedPrescription != null) {
                textBoxDetails.Text = _selectedPrescription.Details;
                _itemsModel = _selectedPrescription.PrescriptionItems.ToList();
                UpdateItems();
                ShowPrescriptionActionButtons();
            }
        }

        private void ShowPrescriptionActionButtons()
        {
            if (_selectedPrescription == null) {
                btnDeletePrescription.Visible = false;
                btnUpdatePrescription.Visible = false;
                btnDeliverPrescription.Visible = false;
            }
            else {
                switch (_selectedPrescription.Status) {
                    case PrescriptionStatus.Sent:
                        btnDeletePrescription.Visible = true;
                        btnUpdatePrescription.Visible = true;
                        btnDeliverPrescription.Visible = false;
                        break;
                    case PrescriptionStatus.Rejected:
                        btnDeletePrescription.Visible = true;
                        btnUpdatePrescription.Visible = true;
                        btnDeliverPrescription.Visible = false;
                        break;
                    case PrescriptionStatus.Honored:
                        btnDeletePrescription.Visible = false;
                        btnUpdatePrescription.Visible = false;
                        btnDeliverPrescription.Visible = true;
                        break;
                    default:
                        btnDeletePrescription.Visible = false;
                        btnUpdatePrescription.Visible = false;
                        btnDeliverPrescription.Visible = false;
                        break;
                }
            }
        }

        private void dataGridViewPrescriptions_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            foreach (DataGridViewRow row in dataGridViewPrescriptions.Rows) {
                var value = row.Cells["Status"].Value;
                if (value!= null && value.Equals(PrescriptionStatus.Rejected) ) {
                    row.DefaultCellStyle.BackColor = Color.Red;
                }
            }
        }
    }
}
