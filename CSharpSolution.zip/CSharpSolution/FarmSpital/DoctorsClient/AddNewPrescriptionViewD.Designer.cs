﻿
namespace DoctorsClient {
    partial class AddNewPrescriptionViewD {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblCurrentlyPrescribing = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridViewDrugs = new System.Windows.Forms.DataGridView();
            this.DrugName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ReservedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewPrescribedItems = new System.Windows.Forms.DataGridView();
            this.ItemDrugName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrescribedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dosage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxSearchDrug = new System.Windows.Forms.TextBox();
            this.textBoxPrescriptionDetails = new System.Windows.Forms.TextBox();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.textBoxDosage = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnRemoveItem = new System.Windows.Forms.Button();
            this.btnUpdateItem = new System.Windows.Forms.Button();
            this.btnSendPrescription = new System.Windows.Forms.Button();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.comboBoxPatients = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDrugs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescribedItems)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(2, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search drug";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(2, 236);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prescribed Drugs";
            // 
            // lblCurrentlyPrescribing
            // 
            this.lblCurrentlyPrescribing.AutoSize = true;
            this.lblCurrentlyPrescribing.Location = new System.Drawing.Point(623, 47);
            this.lblCurrentlyPrescribing.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCurrentlyPrescribing.Name = "lblCurrentlyPrescribing";
            this.lblCurrentlyPrescribing.Size = new System.Drawing.Size(202, 25);
            this.lblCurrentlyPrescribing.TabIndex = 2;
            this.lblCurrentlyPrescribing.Text = "Currently prescribing: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(623, 91);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(623, 187);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Dosage";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(623, 322);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Patient";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(623, 374);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(178, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "Prescription Details";
            // 
            // dataGridViewDrugs
            // 
            this.dataGridViewDrugs.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDrugs.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridViewDrugs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDrugs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DrugName,
            this.AvailableQuantity,
            this.ReservedQuantity});
            this.dataGridViewDrugs.Location = new System.Drawing.Point(7, 47);
            this.dataGridViewDrugs.MultiSelect = false;
            this.dataGridViewDrugs.Name = "dataGridViewDrugs";
            this.dataGridViewDrugs.ReadOnly = true;
            this.dataGridViewDrugs.RowHeadersVisible = false;
            this.dataGridViewDrugs.RowHeadersWidth = 51;
            this.dataGridViewDrugs.RowTemplate.Height = 24;
            this.dataGridViewDrugs.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDrugs.Size = new System.Drawing.Size(609, 186);
            this.dataGridViewDrugs.TabIndex = 7;
            this.dataGridViewDrugs.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDrugs_CellClick);
            // 
            // DrugName
            // 
            this.DrugName.DataPropertyName = "Name";
            this.DrugName.HeaderText = "Drug Name";
            this.DrugName.MinimumWidth = 6;
            this.DrugName.Name = "DrugName";
            this.DrugName.ReadOnly = true;
            // 
            // AvailableQuantity
            // 
            this.AvailableQuantity.DataPropertyName = "AvailableQuantity";
            this.AvailableQuantity.HeaderText = "Available Quantity";
            this.AvailableQuantity.MinimumWidth = 6;
            this.AvailableQuantity.Name = "AvailableQuantity";
            this.AvailableQuantity.ReadOnly = true;
            // 
            // ReservedQuantity
            // 
            this.ReservedQuantity.DataPropertyName = "ReservedQuantity";
            this.ReservedQuantity.HeaderText = "Reserved Quantity";
            this.ReservedQuantity.MinimumWidth = 6;
            this.ReservedQuantity.Name = "ReservedQuantity";
            this.ReservedQuantity.ReadOnly = true;
            // 
            // dataGridViewPrescribedItems
            // 
            this.dataGridViewPrescribedItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPrescribedItems.BackgroundColor = System.Drawing.SystemColors.Window;
            this.dataGridViewPrescribedItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrescribedItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ItemDrugName,
            this.PrescribedQuantity,
            this.Dosage});
            this.dataGridViewPrescribedItems.Location = new System.Drawing.Point(7, 264);
            this.dataGridViewPrescribedItems.MultiSelect = false;
            this.dataGridViewPrescribedItems.Name = "dataGridViewPrescribedItems";
            this.dataGridViewPrescribedItems.ReadOnly = true;
            this.dataGridViewPrescribedItems.RowHeadersVisible = false;
            this.dataGridViewPrescribedItems.RowHeadersWidth = 51;
            this.dataGridViewPrescribedItems.RowTemplate.Height = 24;
            this.dataGridViewPrescribedItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPrescribedItems.Size = new System.Drawing.Size(609, 297);
            this.dataGridViewPrescribedItems.TabIndex = 8;
            this.dataGridViewPrescribedItems.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPrescribedItems_CellClick);
            // 
            // ItemDrugName
            // 
            this.ItemDrugName.DataPropertyName = "Drug";
            this.ItemDrugName.HeaderText = "Drug Name";
            this.ItemDrugName.MinimumWidth = 6;
            this.ItemDrugName.Name = "ItemDrugName";
            this.ItemDrugName.ReadOnly = true;
            // 
            // PrescribedQuantity
            // 
            this.PrescribedQuantity.DataPropertyName = "PrescribedQuantity";
            this.PrescribedQuantity.HeaderText = "Quantity";
            this.PrescribedQuantity.MinimumWidth = 6;
            this.PrescribedQuantity.Name = "PrescribedQuantity";
            this.PrescribedQuantity.ReadOnly = true;
            // 
            // Dosage
            // 
            this.Dosage.DataPropertyName = "Dosage";
            this.Dosage.HeaderText = "Dosage";
            this.Dosage.MinimumWidth = 6;
            this.Dosage.Name = "Dosage";
            this.Dosage.ReadOnly = true;
            // 
            // textBoxSearchDrug
            // 
            this.textBoxSearchDrug.Location = new System.Drawing.Point(128, 6);
            this.textBoxSearchDrug.Name = "textBoxSearchDrug";
            this.textBoxSearchDrug.Size = new System.Drawing.Size(488, 30);
            this.textBoxSearchDrug.TabIndex = 9;
            this.textBoxSearchDrug.TextChanged += new System.EventHandler(this.textBoxSearchDrug_TextChanged);
            // 
            // textBoxPrescriptionDetails
            // 
            this.textBoxPrescriptionDetails.Location = new System.Drawing.Point(628, 402);
            this.textBoxPrescriptionDetails.Multiline = true;
            this.textBoxPrescriptionDetails.Name = "textBoxPrescriptionDetails";
            this.textBoxPrescriptionDetails.Size = new System.Drawing.Size(435, 159);
            this.textBoxPrescriptionDetails.TabIndex = 10;
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(715, 86);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(348, 30);
            this.textBoxQuantity.TabIndex = 12;
            // 
            // textBoxDosage
            // 
            this.textBoxDosage.Location = new System.Drawing.Point(715, 143);
            this.textBoxDosage.Multiline = true;
            this.textBoxDosage.Name = "textBoxDosage";
            this.textBoxDosage.Size = new System.Drawing.Size(348, 109);
            this.textBoxDosage.TabIndex = 13;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.LightCoral;
            this.btnCancel.Location = new System.Drawing.Point(628, 6);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(435, 38);
            this.btnCancel.TabIndex = 14;
            this.btnCancel.Text = "Cancel Writing Prescription";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnRemoveItem
            // 
            this.btnRemoveItem.BackColor = System.Drawing.Color.Red;
            this.btnRemoveItem.Location = new System.Drawing.Point(7, 571);
            this.btnRemoveItem.Name = "btnRemoveItem";
            this.btnRemoveItem.Size = new System.Drawing.Size(297, 45);
            this.btnRemoveItem.TabIndex = 15;
            this.btnRemoveItem.Text = "Remove Prescribed Drug";
            this.btnRemoveItem.UseVisualStyleBackColor = false;
            this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
            // 
            // btnUpdateItem
            // 
            this.btnUpdateItem.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnUpdateItem.Location = new System.Drawing.Point(319, 571);
            this.btnUpdateItem.Name = "btnUpdateItem";
            this.btnUpdateItem.Size = new System.Drawing.Size(297, 45);
            this.btnUpdateItem.TabIndex = 16;
            this.btnUpdateItem.Text = "Update Prescribed Drug";
            this.btnUpdateItem.UseVisualStyleBackColor = false;
            this.btnUpdateItem.Click += new System.EventHandler(this.btnUpdateItem_Click);
            // 
            // btnSendPrescription
            // 
            this.btnSendPrescription.BackColor = System.Drawing.Color.LimeGreen;
            this.btnSendPrescription.Location = new System.Drawing.Point(628, 571);
            this.btnSendPrescription.Name = "btnSendPrescription";
            this.btnSendPrescription.Size = new System.Drawing.Size(435, 45);
            this.btnSendPrescription.TabIndex = 17;
            this.btnSendPrescription.Text = "Send Prescription";
            this.btnSendPrescription.UseVisualStyleBackColor = false;
            this.btnSendPrescription.Click += new System.EventHandler(this.btnSendPrescription_Click);
            // 
            // btnAddItem
            // 
            this.btnAddItem.BackColor = System.Drawing.Color.LightGreen;
            this.btnAddItem.Location = new System.Drawing.Point(715, 264);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(274, 34);
            this.btnAddItem.TabIndex = 18;
            this.btnAddItem.Text = "Add Drug To Prescription";
            this.btnAddItem.UseVisualStyleBackColor = false;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // comboBoxPatients
            // 
            this.comboBoxPatients.FormattingEnabled = true;
            this.comboBoxPatients.Location = new System.Drawing.Point(715, 322);
            this.comboBoxPatients.Name = "comboBoxPatients";
            this.comboBoxPatients.Size = new System.Drawing.Size(348, 33);
            this.comboBoxPatients.TabIndex = 19;
            // 
            // AddNewPrescriptionViewD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1075, 621);
            this.Controls.Add(this.comboBoxPatients);
            this.Controls.Add(this.btnAddItem);
            this.Controls.Add(this.btnSendPrescription);
            this.Controls.Add(this.btnUpdateItem);
            this.Controls.Add(this.btnRemoveItem);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.textBoxDosage);
            this.Controls.Add(this.textBoxQuantity);
            this.Controls.Add(this.textBoxPrescriptionDetails);
            this.Controls.Add(this.textBoxSearchDrug);
            this.Controls.Add(this.dataGridViewPrescribedItems);
            this.Controls.Add(this.dataGridViewDrugs);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblCurrentlyPrescribing);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "AddNewPrescriptionViewD";
            this.Text = "New Prescription";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDrugs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescribedItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblCurrentlyPrescribing;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridViewDrugs;
        private System.Windows.Forms.DataGridViewTextBoxColumn DrugName;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ReservedQuantity;
        private System.Windows.Forms.DataGridView dataGridViewPrescribedItems;
        private System.Windows.Forms.DataGridViewTextBoxColumn ItemDrugName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrescribedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dosage;
        private System.Windows.Forms.TextBox textBoxSearchDrug;
        private System.Windows.Forms.TextBox textBoxPrescriptionDetails;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.TextBox textBoxDosage;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnRemoveItem;
        private System.Windows.Forms.Button btnUpdateItem;
        private System.Windows.Forms.Button btnSendPrescription;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.ComboBox comboBoxPatients;
    }
}