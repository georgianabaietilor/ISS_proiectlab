﻿namespace Common.Events {
    public class AppEventArgs {
        public AppUserEvent Type { get; set; }
        public object Data { get; set; }

        public AppEventArgs(AppUserEvent type, object data)
        {
            Type = type;
            Data = data;
        }
    }

    public enum AppUserEvent {
        PrescriptionAdded = 1,
        PrescriptionDeleted = 2,
        PrescriptionUpdated = 3
    }
}
