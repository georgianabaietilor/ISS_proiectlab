﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Common.Entities {
    [Serializable]
    public class Drug {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [Required]
        public int AvailableQuantity { get; set; }
        [Required]
        public int ReservedQuantity { get; set; }

        public virtual ICollection<PrescriptionItem> PrescriptionItems { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
