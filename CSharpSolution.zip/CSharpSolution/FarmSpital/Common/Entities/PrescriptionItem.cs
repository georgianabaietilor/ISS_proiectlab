﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Common.Entities {
    [Serializable]
    public class PrescriptionItem {
        [Key]
        public int Id { get; set; }
        [Required]
        public int PrescribedQuantity { get; set; }
        [Required]
        [MaxLength(100)]
        public string Dosage { get; set; }
        [Required]
        public int PrescriptionId { get; set; }
        public Prescription Prescription { get; set; }
        [Required]
        public int DrugId { get; set; }
        public Drug Drug { get; set; }

    }
}
