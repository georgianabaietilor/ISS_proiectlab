﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Common.Entities {
    [Serializable]
    public class Doctor : MedicalStaff {
        [Required]
        [MaxLength(100)]
        public string Department { get; set; }
    }
}
