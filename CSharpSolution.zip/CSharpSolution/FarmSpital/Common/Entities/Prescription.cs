﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Common.Entities {
    [Serializable]
    public class Prescription {
        [Key]
        public int Id { get; set; }
        [Required]
        public DateTime DateAndTime { get; set; }
        [Required]
        public PrescriptionStatus Status { get; set; }
        [MaxLength(1000)]
        public string Details { get; set; }
        [Required]
        public int DoctorId { get; set; }
        public Doctor Doctor { get; set; }
        [Required]
        public int PatientId { get; set; }
        public Patient Patient { get; set; }
        public int PharmacistId { get; set; }
        public Pharmacist Pharmacist { get; set; }
        public virtual ICollection<PrescriptionItem> PrescriptionItems { get; set; }

        public override bool Equals(object obj)
        {
            return obj is Prescription prescription &&
                   Id == prescription.Id;
        }

        public override int GetHashCode()
        {
            return 2108858624 + Id.GetHashCode();
        }
    }
    [Serializable]
    public enum PrescriptionStatus {
        Sent = 1,
        Processing = 2,
        Honored = 3,
        Rejected = 4,
        Delivered = 5
    }
}
