﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Common.Entities {
    [Serializable]
    public abstract class MedicalStaff
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }
        [Required]
        [MaxLength(100)]
        public string Username { get; set; }
        [Required]
        [MaxLength(100)]
        public string Password { get; set; }

    }
}
