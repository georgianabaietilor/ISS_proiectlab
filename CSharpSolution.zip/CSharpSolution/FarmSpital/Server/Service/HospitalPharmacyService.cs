﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Common.Entities;
using Common.Exceptions;
using Common.Interfaces;
using Server.Repository;

namespace Server.Service {
    public class HospitalPharmacyService : MarshalByRefObject, IService {
        private readonly IDoctorRepository _doctorRepository;
        private readonly IPharmacistRepository _pharmacistRepository;
        private readonly IDrugRepository _drugRepository;
        private readonly IPatientRepository _patientRepository;
        private readonly IPrescriptionRepository _prescriptionRepository;
        private readonly IPrescriptionItemRepository _prescriptionItemRepository;

        private IDictionary<string, IObserver> _loggedClients;

        public HospitalPharmacyService(IDoctorRepository doctorRepository,
            IPharmacistRepository pharmacistRepository,
            IDrugRepository drugRepository,
            IPatientRepository patientRepository,
            IPrescriptionRepository prescriptionRepository, 
            IPrescriptionItemRepository prescriptionItemRepository)
        {
            _doctorRepository = doctorRepository;
            _pharmacistRepository = pharmacistRepository;
            _drugRepository = drugRepository;
            _patientRepository = patientRepository;
            _prescriptionItemRepository = prescriptionItemRepository;
            _prescriptionRepository = prescriptionRepository;

            _loggedClients = new Dictionary<string, IObserver>();
        }
        public bool AddNewPrescription(Prescription prescription)
        {
            foreach (var item in prescription.PrescriptionItems) {
                item.Drug.ReservedQuantity += item.PrescribedQuantity;
                _drugRepository.Update(item.Drug);
                item.Drug = null;
            }
            if (_prescriptionRepository.Save(prescription) == null) {
                var added = _prescriptionRepository.FindOne(prescription.Id);
                NotifyPrescriptionWasAdded(added);
                return true;
            }
            return false;
        }

        private void NotifyPrescriptionWasAdded(Prescription added)
        {
            foreach (var pair in _loggedClients)
                Task.Run( () => pair.Value.PrescriptionWasAdded(added));
        }
        public bool UpdatePrescription(Prescription prescription, List<PrescriptionItem> newAddedItems, List<int> deletedItemsIds, List<PrescriptionItem> updatedItems)
        {
            prescription.PrescriptionItems = null;
            if (!_prescriptionRepository.Update(prescription))
                return false;
            foreach(var item in newAddedItems) {
                item.Prescription = null;
                item.PrescriptionId = prescription.Id;
                item.Drug = null;
                _prescriptionItemRepository.Save(item);
            }
            foreach(var id in deletedItemsIds) {
                _prescriptionItemRepository.Delete(id);
            }
            foreach(var item in updatedItems) {
                _prescriptionItemRepository.Update(item);
            }
            var updatedPrescription = _prescriptionRepository.FindOne(prescription.Id);
            if (updatedPrescription!=null)
                NotifyPrescriptionWasUpdated(updatedPrescription);
            return true;
        }
        private void NotifyPrescriptionWasUpdated(Prescription prescription)
        {
            foreach (var pair in _loggedClients)
                Task.Run(() => pair.Value.PrescriptionWasUpdated(prescription));
        }
        public bool DeletePrescription(int id)
        {
            var toBeDeleted = _prescriptionRepository.FindOne(id);
            if (toBeDeleted == null)
                return false;
            foreach(var item in toBeDeleted.PrescriptionItems) {
                var updatedItem = new PrescriptionItem() {
                    Id = item.Id,
                    PrescribedQuantity = 0,
                    PrescriptionId = item.PrescriptionId,
                    DrugId = item.DrugId,
                    Dosage = item.Dosage
                };
                _prescriptionItemRepository.Update(updatedItem);
            }
            if (!_prescriptionRepository.Delete(id))
                return false;
            NotifyPrescriptionWasDeleted(id);
            return true;
        }

        private void NotifyPrescriptionWasDeleted(int id)
        {
            foreach (var pair in _loggedClients)
                Task.Run(() => pair.Value.PrescriptionWasDeleted(id));
        }

        public IEnumerable<Drug> FilterDrugsByName(string name)
        {
            return _drugRepository.FilterByName(name);
        }

        public IEnumerable<Patient> FindAllPatients()
        {
            return _patientRepository.FindAll();
        }

        public MedicalStaff Login(MedicalStaff staff, IObserver client)
        {
            Console.WriteLine($"Login {staff.Username}");
            if (_loggedClients.ContainsKey(staff.Username))
                throw new AppException("User already logged in");

            MedicalStaff medicalStaff = null;
            if (staff is Doctor)
                medicalStaff = _doctorRepository.FindOne(staff.Username);
            if (staff is Pharmacist)
                medicalStaff = _pharmacistRepository.FindOne(staff.Username);
            if (medicalStaff == null)
                throw new AppException("Username not found");

            if (!medicalStaff.Password.Equals(staff.Password))
                throw new AppException("Wrong password");

            _loggedClients[staff.Username] = client;
            Console.WriteLine($"Login successful for {staff.Username}");
            return medicalStaff;
        }

        public void Logout(string username)
        {
            Console.WriteLine($"Logout {username}");
            var loggedIn = _loggedClients[username];
            if (loggedIn == null)
                throw new AppException("User not logged in");
            _loggedClients.Remove(username);
            Console.WriteLine($"Logout successful for {username}");

        }

        public bool RejectPrescription(Prescription prescription, string rejectionMotiv)
        {
            prescription.Details = $"Rejection motiv: {rejectionMotiv};\n{prescription.Details}";
            prescription.Status = PrescriptionStatus.Rejected;
            _prescriptionRepository.Update(prescription);
            NotifyPrescriptionWasUpdated(prescription);
            return true;
        }


        public bool UpdatePrescriptionStatus(Prescription prescription, PrescriptionStatus newStatus)
        {
            prescription.Status = newStatus;
            _prescriptionRepository.Update(prescription);
            NotifyPrescriptionWasUpdated(prescription);
            return true;
        }
        //ca sa mearga .NET remoting
        public override object InitializeLifetimeService()
        {
            return null;
        }

        public IEnumerable<Prescription> FilterByStatusAndDoctor(IEnumerable<PrescriptionStatus> statuses, int? doctorId = null)
        {
            return _prescriptionRepository.FilterByStatusAndDoctor(statuses, doctorId);
        }

        public void HonorPrescription(Prescription prescription)
        {
            prescription.Status = PrescriptionStatus.Honored;
            _prescriptionRepository.Update(prescription);
            foreach(var item in prescription.PrescriptionItems) {
                var drug = item.Drug;
                drug.AvailableQuantity -= item.PrescribedQuantity;
                drug.ReservedQuantity -= item.PrescribedQuantity;
                _drugRepository.Update(drug);
            }
            NotifyPrescriptionWasUpdated(prescription);
        }
    }
}
