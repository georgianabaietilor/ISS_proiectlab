﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Common.Entities;

namespace Server.Repository {
    public interface IPrescriptionRepository : IRepository<Prescription,int>{
        IEnumerable<Prescription> FilterByStatusAndDoctor(IEnumerable<PrescriptionStatus> statuses, int? doctorId=null);
    }

    public class DbPrescriptionRepository : IPrescriptionRepository {
        private readonly AppDbContext _context;

        public DbPrescriptionRepository(AppDbContext context)
        {
            _context = context;
        }

        public bool Delete(int id)
        {
            var toBeDeleted = _context.Prescriptions.FirstOrDefault(p => p.Id == id);
            if (toBeDeleted == null)
                return false;
            _context.Prescriptions.Remove(toBeDeleted);
            _context.SaveChanges();
            return true;
        }

        public IEnumerable<Prescription> FilterByStatusAndDoctor(IEnumerable<PrescriptionStatus> statuses, int? doctorId = null)
        {
            if (doctorId.HasValue)
                return _context.Prescriptions
                    .Where(p => statuses.Contains(p.Status) && p.DoctorId == doctorId.Value)
                    .Include(p => p.Patient)
                    .Include(p => p.PrescriptionItems.Select(pi=>pi.Drug))
                    .ToList();
            return _context.Prescriptions
                .Where(p => statuses.Contains(p.Status))
                .Include(p => p.Doctor)
                .Include(p => p.Patient)
                .Include(p => p.PrescriptionItems.Select(pi => pi.Drug))
                .ToList();
        }


        public Prescription Save(Prescription entity)
        {
            _context.Prescriptions.Add(entity);
            if (_context.SaveChanges() > 0)
                return null;
            return entity;
        }

        public bool Update(Prescription entity)
        {
            var toBeUpdated = _context.Prescriptions.FirstOrDefault(p => p.Id == entity.Id);
            if (toBeUpdated == null)
                return false;
            //toBeUpdated.DateAndTime = entity.DateAndTime;
            toBeUpdated.Status = entity.Status;
            toBeUpdated.Details = entity.Details;
            //toBeUpdated.DoctorId = entity.DoctorId;
            //toBeUpdated.PatientId = entity.PatientId;
            toBeUpdated.PharmacistId = entity.PharmacistId;
            //toBeUpdated.PrescriptionItems = entity.PrescriptionItems;
            _context.SaveChanges();
            return true;
        }
        public Prescription FindOne(int id)
        {
            return _context.Prescriptions
                .Include(p => p.Doctor)
                .Include(p => p.Patient)
                .Include(p => p.PrescriptionItems.Select(pi => pi.Drug))
                .FirstOrDefault(p => p.Id == id);
        }
        #region not implemented

        public IEnumerable<Prescription> FindAll()
        {
            throw new System.NotImplementedException();
        }

        
        #endregion
    }
}
