﻿using System.Collections.Generic;
using System.Linq;
using Common.Entities;

namespace Server.Repository {
    public interface IPatientRepository : IRepository<Patient,int>{
    }

    public class DbPatientRepository : IPatientRepository {
        private readonly AppDbContext _context;

        public DbPatientRepository(AppDbContext context)
        {
            _context = context;
        }
        public IEnumerable<Patient> FindAll()
        {
            return _context.Patients.ToList();
        }

        #region not implemented
        public bool Delete(int id)
        {
            throw new System.NotImplementedException();
        }

        public Patient FindOne(int id)
        {
            throw new System.NotImplementedException();
        }

        public Patient Save(Patient entity)
        {
            throw new System.NotImplementedException();
        }

        public bool Update(Patient entity)
        {
            throw new System.NotImplementedException();
        }
        #endregion
    }
}
