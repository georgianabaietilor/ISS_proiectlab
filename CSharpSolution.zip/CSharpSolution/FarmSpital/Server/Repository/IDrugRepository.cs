﻿using System.Collections.Generic;
using System.Linq;
using Common.Entities;

namespace Server.Repository {
    public interface IDrugRepository : IRepository<Drug,int> {
        IEnumerable<Drug> FilterByName(string name);
    }

    public class DbDrugRepository : IDrugRepository {
        private readonly AppDbContext _context;

        public DbDrugRepository(AppDbContext context)
        {
            _context = context;
        }

        public IEnumerable<Drug> FilterByName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return _context.Drugs.ToList();
            return _context.Drugs.Where(d => d.Name.ToUpper().Contains(name.ToUpper())).ToList();
        }

        public IEnumerable<Drug> FindAll()
        {
            return _context.Drugs.ToList();
        }
        public bool Update(Drug entity)
        {
            var toBeUpdated = _context.Drugs.FirstOrDefault(d => d.Id==entity.Id);
            if (toBeUpdated == null)
                return false;
            toBeUpdated.ReservedQuantity = entity.ReservedQuantity;
            toBeUpdated.AvailableQuantity = entity.AvailableQuantity;
            _context.SaveChanges();
            return true;
        }
        public Drug FindOne(int id)
        {
            return _context.Drugs.FirstOrDefault(d => d.Id==id);
        }
        #region not implemented
        public bool Delete(int id)
        {
            throw new System.NotImplementedException();
        }

        public Drug Save(Drug entity)
        {
            throw new System.NotImplementedException();
        }

        #endregion
    }
}
