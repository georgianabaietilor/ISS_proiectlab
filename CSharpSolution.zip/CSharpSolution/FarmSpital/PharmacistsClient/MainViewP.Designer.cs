﻿
namespace PharmacistsClient {
    partial class MainViewP {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblLoggedUser = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridViewPrescriptions = new System.Windows.Forms.DataGridView();
            this.DateAndTime = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Patient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewPrescriptionItems = new System.Windows.Forms.DataGridView();
            this.DrugName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrescribedQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dosage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBoxDetails = new System.Windows.Forms.TextBox();
            this.btnRejectPrescription = new System.Windows.Forms.Button();
            this.btnHonorPrescription = new System.Windows.Forms.Button();
            this.btnProcessPrescription = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptionItems)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLoggedUser
            // 
            this.lblLoggedUser.AutoSize = true;
            this.lblLoggedUser.Location = new System.Drawing.Point(-4, 9);
            this.lblLoggedUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLoggedUser.Name = "lblLoggedUser";
            this.lblLoggedUser.Size = new System.Drawing.Size(186, 25);
            this.lblLoggedUser.TabIndex = 0;
            this.lblLoggedUser.Text = "Currently logged in: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-4, 53);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prescriptions";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(588, 178);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Prescribed Drugs";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(588, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Prescription Details";
            // 
            // dataGridViewPrescriptions
            // 
            this.dataGridViewPrescriptions.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPrescriptions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrescriptions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DateAndTime,
            this.Patient,
            this.Status});
            this.dataGridViewPrescriptions.Location = new System.Drawing.Point(1, 81);
            this.dataGridViewPrescriptions.MultiSelect = false;
            this.dataGridViewPrescriptions.Name = "dataGridViewPrescriptions";
            this.dataGridViewPrescriptions.ReadOnly = true;
            this.dataGridViewPrescriptions.RowHeadersVisible = false;
            this.dataGridViewPrescriptions.RowHeadersWidth = 51;
            this.dataGridViewPrescriptions.RowTemplate.Height = 24;
            this.dataGridViewPrescriptions.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPrescriptions.Size = new System.Drawing.Size(586, 459);
            this.dataGridViewPrescriptions.TabIndex = 4;
            this.dataGridViewPrescriptions.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPrescriptions_CellClick);
            // 
            // DateAndTime
            // 
            this.DateAndTime.DataPropertyName = "DateAndTime";
            this.DateAndTime.HeaderText = "Prescribed On";
            this.DateAndTime.MinimumWidth = 6;
            this.DateAndTime.Name = "DateAndTime";
            this.DateAndTime.ReadOnly = true;
            // 
            // Patient
            // 
            this.Patient.DataPropertyName = "Patient";
            this.Patient.HeaderText = "Patient";
            this.Patient.MinimumWidth = 6;
            this.Patient.Name = "Patient";
            this.Patient.ReadOnly = true;
            // 
            // Status
            // 
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.MinimumWidth = 6;
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // dataGridViewPrescriptionItems
            // 
            this.dataGridViewPrescriptionItems.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPrescriptionItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrescriptionItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.DrugName,
            this.PrescribedQuantity,
            this.Dosage});
            this.dataGridViewPrescriptionItems.Location = new System.Drawing.Point(593, 206);
            this.dataGridViewPrescriptionItems.MultiSelect = false;
            this.dataGridViewPrescriptionItems.Name = "dataGridViewPrescriptionItems";
            this.dataGridViewPrescriptionItems.ReadOnly = true;
            this.dataGridViewPrescriptionItems.RowHeadersVisible = false;
            this.dataGridViewPrescriptionItems.RowHeadersWidth = 51;
            this.dataGridViewPrescriptionItems.RowTemplate.Height = 24;
            this.dataGridViewPrescriptionItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPrescriptionItems.Size = new System.Drawing.Size(468, 395);
            this.dataGridViewPrescriptionItems.TabIndex = 5;
            // 
            // DrugName
            // 
            this.DrugName.DataPropertyName = "Drug";
            this.DrugName.HeaderText = "Drug Name";
            this.DrugName.MinimumWidth = 6;
            this.DrugName.Name = "DrugName";
            this.DrugName.ReadOnly = true;
            // 
            // PrescribedQuantity
            // 
            this.PrescribedQuantity.DataPropertyName = "PrescribedQuantity";
            this.PrescribedQuantity.HeaderText = "Quantity";
            this.PrescribedQuantity.MinimumWidth = 6;
            this.PrescribedQuantity.Name = "PrescribedQuantity";
            this.PrescribedQuantity.ReadOnly = true;
            // 
            // Dosage
            // 
            this.Dosage.DataPropertyName = "Dosage";
            this.Dosage.HeaderText = "Dosage";
            this.Dosage.MinimumWidth = 6;
            this.Dosage.Name = "Dosage";
            this.Dosage.ReadOnly = true;
            // 
            // textBoxDetails
            // 
            this.textBoxDetails.Location = new System.Drawing.Point(593, 37);
            this.textBoxDetails.Multiline = true;
            this.textBoxDetails.Name = "textBoxDetails";
            this.textBoxDetails.ReadOnly = true;
            this.textBoxDetails.Size = new System.Drawing.Size(468, 138);
            this.textBoxDetails.TabIndex = 6;
            // 
            // btnRejectPrescription
            // 
            this.btnRejectPrescription.BackColor = System.Drawing.Color.Red;
            this.btnRejectPrescription.Location = new System.Drawing.Point(1, 548);
            this.btnRejectPrescription.Name = "btnRejectPrescription";
            this.btnRejectPrescription.Size = new System.Drawing.Size(184, 60);
            this.btnRejectPrescription.TabIndex = 7;
            this.btnRejectPrescription.Text = "Reject Prescription";
            this.btnRejectPrescription.UseVisualStyleBackColor = false;
            this.btnRejectPrescription.Click += new System.EventHandler(this.btnRejectPrescription_Click);
            // 
            // btnHonorPrescription
            // 
            this.btnHonorPrescription.BackColor = System.Drawing.Color.LimeGreen;
            this.btnHonorPrescription.Location = new System.Drawing.Point(399, 548);
            this.btnHonorPrescription.Name = "btnHonorPrescription";
            this.btnHonorPrescription.Size = new System.Drawing.Size(188, 60);
            this.btnHonorPrescription.TabIndex = 8;
            this.btnHonorPrescription.Text = "Honor Prescription";
            this.btnHonorPrescription.UseVisualStyleBackColor = false;
            this.btnHonorPrescription.Click += new System.EventHandler(this.btnHonorPrescription_Click);
            // 
            // btnProcessPrescription
            // 
            this.btnProcessPrescription.BackColor = System.Drawing.Color.SkyBlue;
            this.btnProcessPrescription.Location = new System.Drawing.Point(191, 548);
            this.btnProcessPrescription.Name = "btnProcessPrescription";
            this.btnProcessPrescription.Size = new System.Drawing.Size(202, 60);
            this.btnProcessPrescription.TabIndex = 9;
            this.btnProcessPrescription.Text = "Process Prescription";
            this.btnProcessPrescription.UseVisualStyleBackColor = false;
            this.btnProcessPrescription.Click += new System.EventHandler(this.btnProcessPrescription_Click);
            // 
            // MainViewP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1073, 613);
            this.Controls.Add(this.btnProcessPrescription);
            this.Controls.Add(this.btnHonorPrescription);
            this.Controls.Add(this.btnRejectPrescription);
            this.Controls.Add(this.textBoxDetails);
            this.Controls.Add(this.dataGridViewPrescriptionItems);
            this.Controls.Add(this.dataGridViewPrescriptions);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblLoggedUser);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainViewP";
            this.Text = "View Prescriptions Pharmacists";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrescriptionItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLoggedUser;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridViewPrescriptions;
        private System.Windows.Forms.DataGridView dataGridViewPrescriptionItems;
        private System.Windows.Forms.TextBox textBoxDetails;
        private System.Windows.Forms.Button btnRejectPrescription;
        private System.Windows.Forms.Button btnHonorPrescription;
        private System.Windows.Forms.Button btnProcessPrescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateAndTime;
        private System.Windows.Forms.DataGridViewTextBoxColumn Patient;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
        private System.Windows.Forms.DataGridViewTextBoxColumn DrugName;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrescribedQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dosage;
    }
}