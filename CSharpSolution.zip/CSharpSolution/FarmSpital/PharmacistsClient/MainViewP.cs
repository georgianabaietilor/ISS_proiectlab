﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Common.Entities;
using Common.Events;
using Microsoft.VisualBasic;

namespace PharmacistsClient {
    public partial class MainViewP : Form {
        private readonly ControllerP _controller;
        private Prescription _selectedPrescription;

        private List<Prescription> _prescriptionsModel;
        private List<PrescriptionItem> _itemsModel;
        public MainViewP(ControllerP controller)
        {
            InitializeComponent();
            _controller = controller;
            lblLoggedUser.Text = $"Pharmacist logged in: {_controller.LoggedPharmacist.Name}";
            _prescriptionsModel = _controller.FindAllSentAndProcesssingPrescriptions().ToList();
            dataGridViewPrescriptions.DataSource = _prescriptionsModel;
            HideUnwantedPrescriptionsColumns();
            ShowPrescriptionActionButtons();

            _controller.UpdateEvent += UserUpdate;
        }
        public delegate void UpdateDataGridViewCallBack(DataGridView dataGridView, IList<Prescription> prescriptions);
        private void UserUpdate(object sender, AppEventArgs e)
        {
            switch (e.Type) {
                case AppUserEvent.PrescriptionAdded:
                    var addedPrescription = e.Data as Prescription;
                    if (addedPrescription.Status.Equals(PrescriptionStatus.Honored)
                        || addedPrescription.Status.Equals(PrescriptionStatus.Processing)
                        || addedPrescription.Status.Equals(PrescriptionStatus.Rejected)
                        || addedPrescription.Status.Equals(PrescriptionStatus.Sent))
                        _prescriptionsModel.Add(addedPrescription);
                    dataGridViewPrescriptions.Invoke(new UpdateDataGridViewCallBack(this.UpdateDataGridView), new Object[] { dataGridViewPrescriptions, _prescriptionsModel });
                    break;
                case AppUserEvent.PrescriptionUpdated:
                    var updatedPrescription = e.Data as Prescription;
                    var inModelPrescription = _prescriptionsModel.FirstOrDefault(p => p.Id == updatedPrescription.Id);
                    if (inModelPrescription != null) {
                        _prescriptionsModel.Remove(inModelPrescription);
                    }
                    if (updatedPrescription.Status.Equals(PrescriptionStatus.Sent)
                        || updatedPrescription.Status.Equals(PrescriptionStatus.Processing))
                        _prescriptionsModel.Add(updatedPrescription);
                    
                    _prescriptionsModel = _prescriptionsModel.OrderBy(p => p.DateAndTime).ToList();
                    dataGridViewPrescriptions.Invoke(new UpdateDataGridViewCallBack(this.UpdateDataGridView), new Object[] { dataGridViewPrescriptions, _prescriptionsModel });
                    break;
                case AppUserEvent.PrescriptionDeleted:
                    var id = (int)e.Data;
                    var pr = _prescriptionsModel.FirstOrDefault(p => p.Id == id);
                    if (pr != null) {
                        _prescriptionsModel.Remove(pr);
                    }
                    dataGridViewPrescriptions.Invoke(new UpdateDataGridViewCallBack(this.UpdateDataGridView), new Object[] { dataGridViewPrescriptions, _prescriptionsModel });
                    break;
            }
        }
        private void UpdateDataGridView(DataGridView dataGridView, IList<Prescription> prescriptions)
        {
            dataGridView.DataSource = null;
            dataGridView.DataSource = prescriptions;
            HideUnwantedPrescriptionsColumns();
        }
        private void HideUnwantedPrescriptionsColumns()
        {
            dataGridViewPrescriptions.Columns["Id"].Visible = false;
            dataGridViewPrescriptions.Columns["Details"].Visible = false;
            dataGridViewPrescriptions.Columns["DoctorId"].Visible = false;
            dataGridViewPrescriptions.Columns["Doctor"].Visible = false;
            dataGridViewPrescriptions.Columns["PatientId"].Visible = false;
            dataGridViewPrescriptions.Columns["PharmacistId"].Visible = false;
            dataGridViewPrescriptions.Columns["Pharmacist"].Visible = false;
            dataGridViewPrescriptions.Columns["PrescriptionItems"].Visible = false;

        }
        private void HideUnwantedItemColumns()
        {
            dataGridViewPrescriptionItems.Columns["Id"].Visible = false;
            dataGridViewPrescriptionItems.Columns["PrescriptionId"].Visible = false;
            dataGridViewPrescriptionItems.Columns["Prescription"].Visible = false;
            dataGridViewPrescriptionItems.Columns["DrugId"].Visible = false;
        }
        private void UpdateItems()
        {
            dataGridViewPrescriptionItems.DataSource = null;
            dataGridViewPrescriptionItems.DataSource = _itemsModel;
            HideUnwantedItemColumns();
        }
        private void MainViewD_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing) {
                _controller.Logout();
                _controller.UpdateEvent -= UserUpdate;
                Application.Exit();
            }
        }
        
        private void ShowPrescriptionActionButtons()
        {
            if (_selectedPrescription == null) {
                btnProcessPrescription.Visible = false;
                btnRejectPrescription.Visible = false;
                btnHonorPrescription.Visible = false;
            }
            else {
                switch (_selectedPrescription.Status) {
                    case PrescriptionStatus.Sent:
                        btnProcessPrescription.Visible = true;
                        btnRejectPrescription.Visible = true;
                        btnHonorPrescription.Visible = false;
                        break;
                    case PrescriptionStatus.Processing:
                        btnProcessPrescription.Visible = false;
                        btnRejectPrescription.Visible = true;
                        btnHonorPrescription.Visible = true;
                        break;
                    default:
                        btnProcessPrescription.Visible = false;
                        btnRejectPrescription.Visible = false;
                        btnHonorPrescription.Visible = false;
                        break;
                }
            }
        }

        private void btnRejectPrescription_Click(object sender, EventArgs e)
        {
            if (_selectedPrescription == null) {
                MessageBox.Show("Please select the prescription you want to reject.");
                return;
            }
            if (!_selectedPrescription.Status.Equals(PrescriptionStatus.Sent) 
                && !_selectedPrescription.Status.Equals(PrescriptionStatus.Processing)) {
                MessageBox.Show("Cannot reject a prescription with status different than Sent/Processing.");
                return;
            }
            var rejectionMotiv = Interaction.InputBox("Rejection motiv", "Enter rejection motiv", "");
            if (string.IsNullOrWhiteSpace(rejectionMotiv)) {
                MessageBox.Show("Cannot reject a prescription without giving a motiv.");
                return;
            }
            _selectedPrescription.PharmacistId = _controller.LoggedPharmacist.Id;
            _selectedPrescription.Pharmacist = _controller.LoggedPharmacist;
            _controller.RejectPrescription(_selectedPrescription, rejectionMotiv);
        }

        private void btnProcessPrescription_Click(object sender, EventArgs e)
        {
            if (_selectedPrescription == null) {
                MessageBox.Show("Please select the prescription you want to process.");
                return;
            }
            if (!_selectedPrescription.Status.Equals(PrescriptionStatus.Sent)) {
                MessageBox.Show("Cannot process a prescription with status different than Sent.");
                return;
            }
            _selectedPrescription.PharmacistId = _controller.LoggedPharmacist.Id;
            _selectedPrescription.Pharmacist = _controller.LoggedPharmacist;
            _controller.UpdatePrescriptionStatus(_selectedPrescription, PrescriptionStatus.Processing);
        }

        private void btnHonorPrescription_Click(object sender, EventArgs e)
        {
            if (_selectedPrescription == null) {
                MessageBox.Show("Please select the prescription you want to honor.");
                return;
            }
            if (!_selectedPrescription.Status.Equals(PrescriptionStatus.Processing)) {
                MessageBox.Show("Cannot honor a prescription with status different than Processing.");
                return;
            }
            _selectedPrescription.PharmacistId = _controller.LoggedPharmacist.Id;
            _selectedPrescription.PharmacistId = _controller.LoggedPharmacist.Id;
            _selectedPrescription.Pharmacist = _controller.LoggedPharmacist;
            _controller.HonorPrescription(_selectedPrescription);
        }

        private void dataGridViewPrescriptions_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            _selectedPrescription = dataGridViewPrescriptions.SelectedRows?[0].DataBoundItem as Prescription;
            if (_selectedPrescription != null) {
                textBoxDetails.Text = _selectedPrescription.Details;
                _itemsModel = _selectedPrescription.PrescriptionItems.ToList();
                UpdateItems();
                ShowPrescriptionActionButtons();
            }
        }
    }
}
